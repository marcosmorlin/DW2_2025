    <ul class="nav nav-pills">
        <li class="nav-item"><a href="contato.php" class="nav-link active" aria-current="page">Formulário</a></li>
        <li class="nav-item"><a href="listagem.php" class="nav-link">Listagem</a></li>
    </ul>